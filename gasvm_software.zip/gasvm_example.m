%Author: Panfeng Ji. Aerospace Information Research Institute, Chinese Academy of Science
clear;
close all;
sim3d(0.004, 0.004, 0.008);
selgnss('sim3d.mat', 100); %please pause here to see if the selected GNSS distribution is appropriate
syninsar('sim3d.mat', [0.34 -0.095 0.935], [-0.34 0.095 0.935], 0.009, 0.009);
makedata('sim3d.mat', 'gnss100.mat','insar.mat');
gaoption=[300 50 0 200 0 100 5];
gasvme('sim3d.mat','gnsssvm.mat','insar.mat',gaoption);
gasvmn('sim3d.mat','gnsssvm.mat','insar.mat',gaoption);
gasvmu('sim3d.mat','gnsssvm.mat','insar.mat',gaoption);